module.exports={
  
  //define db url/ with DB name
  url:'mongodb://localhost:27017/research'
}

// var MongoClient=require('mongodb').MongoClient;
// var url="mongodb://localhost:27017/researchapp";

// MongoClient.connect(url,function(err,db){
//   if(err) throw err;
//   console.log("Datbase Created");
//   db.close();
// });