const mongoose=require('mongoose');
const Schema = mongoose.Schema;

let User = new Schema({
    name:{
        type:String
    },
    email:{
        type:String
    },
    mobileno:{
        type:Number
    },
    comment:{
        type:String
    }
},
{
    collection:'user'
}
);






let Partner = new Schema({
    name:{
        type:String
    },
    email:{
        type:String
    },
    mobileno:{
        type:Number
    },
    comment:{
        type:String
    }
},
{
    colliection:'PartnerInfo'
}
);

module.exports = mongoose.model('PartnerInfo',Partner);